<?php


/*

	Orignal Code Copied from @f4c3r100 Telegram by noob coder lol

*/


$settings = array(
	"telegram"		=> "1", 						// Telegram Bots Receiver
	"chat_id"		=> "", 							// Chat ID Of You
	"bot_url"		=> "", 							// Your Bot API Key [Please add bot'apikey']
);

return $settings;

?>