<?php
die(header("Location: /"));
?>