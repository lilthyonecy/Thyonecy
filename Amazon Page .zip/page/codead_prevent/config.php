<?php

/**

            
 */
 $countryblock = "off"; // only access with a single country
 $whichcountry = "JP"; // specify country code on allcaps examp JP for Japan

 $ipquality = "on"; //check ip quality on/on 
 $vpndetect = "on"; //vpn detection on/on
 $proxydetect = "on"; //proxy detection on/on
 $tordetetct = "on" ;//tor detection on/on

 $crawlerdetect2= "on"; //another method to detect crawler turn both on for advance protection

 $badisp = "on"; // protect against bots by blocking them by isp
 $badhost = "on"; // protect against bots by blocking them by hostname
 $badua = "on"; // protect against bots by blocking them by useragent
 $badasn = "on"; // protect against bots by blocking them by asn

 
 $ondb= "on"; //antibot lite version
?>
