from Funcs import Main as send

if __name__ == "__main__":
	send
